import { useEffect, useState } from 'react';
import {
  Check,
  Copy,
  Download,
  ExternalLink,
  FileText,
  Loader2,
  MessageCircle,
  Receipt,
  Share2,
  X,
} from 'lucide-react';
import {
  buildKhataWhatsAppReminderMessage,
  KhataCustomerSummary,
} from '../services/khataEngine';
import {
  buildReceiptFileName,
  canSharePdfFiles,
  generateReceiptPdf,
  ReceiptLayoutMode,
  shareReceiptPdfViaWhatsApp,
  triggerPdfDownload,
} from '../services/receiptPdfService';
import {
  computeJobFinancials,
  digitsOnly,
  JobStage,
  RepairJob,
  ShopProfile,
  STAGE_LABELS,
} from '../types/repairShop';

interface WhatsAppModalProps {
  isOpen: boolean;
  job: RepairJob | null;
  khataCustomer?: KhataCustomerSummary | null;
  shopProfile: ShopProfile | null;
  initialReceiptLayout?: ReceiptLayoutMode;
  onClose: () => void;
}

function buildDefaultMessage(
  job: RepairJob,
  shopProfile: ShopProfile | null,
  template: 'auto' | 'status' | 'ready' | 'delivered'
): string {
  const shopName = shopProfile?.shopName || 'Mobile Repair Shop';
  const shopContact = shopProfile?.contactPhone || shopProfile?.whatsappNumber || '';
  const currency = shopProfile?.currencySymbol || '₹';
  const warrantyDays = shopProfile?.warrantyDays ?? 90;
  const fin = computeJobFinancials(job);
  const device = [job.deviceBrand, job.deviceModel].filter(Boolean).join(' ') || 'your device';
  const stageLabel = STAGE_LABELS[job.stage] || job.stage;

  const effectiveMode =
    template === 'auto'
      ? job.stage === JobStage.READY_FOR_PICKUP
        ? 'ready'
        : job.stage === JobStage.DELIVERED
          ? 'delivered'
          : 'status'
      : template;

  const greeting = `Hello ${job.customerName || 'Customer'},`;
  const footer = [
    `Warranty: ${warrantyDays} days on replaced parts (as per shop terms).`,
    shopContact ? `Contact: ${shopContact}` : '',
    `— ${shopName}`,
  ]
    .filter(Boolean)
    .join('\n');

  const billingBlock = [
    `Total/Est Cost: ${currency}${fin.totalCost.toLocaleString()}`,
    `Advance Paid: ${currency}${fin.advancePaid.toLocaleString()}`,
    fin.discount > 0 ? `Discount: ${currency}${fin.discount.toLocaleString()}` : '',
    fin.isFullyPaid
      ? `Payment Status: PAID (${job.paymentMode || 'Cash'})`
      : `Balance Due: ${currency}${fin.balanceDue.toLocaleString()}`,
  ]
    .filter(Boolean)
    .join('\n');

  if (effectiveMode === 'ready') {
    return `${greeting}

Your device *${device}* (Job *${job.jobNumber}*) is *Ready for Pickup*!
Issue: ${job.issueDescription || 'Repair completed'}

${billingBlock}

Please find your repair receipt PDF attached. Visit ${shopName} to collect your device.
${footer}`;
  }

  if (effectiveMode === 'delivered') {
    return `${greeting}

Thank you for choosing *${shopName}*. Your device *${device}* (Job *${job.jobNumber}*) has been *Delivered*.
Issue: ${job.issueDescription || 'Repaired'}

${billingBlock}

Please find your final invoice / job card PDF attached.
${footer}`;
  }

  return `${greeting}

Update for your repair ticket *${job.jobNumber}* at *${shopName}*:
Device: ${device}
Current Stage: *${stageLabel}*
Reported Issue: ${job.issueDescription || '—'}

${billingBlock}

Please find your job card receipt PDF attached.
${footer}`;
}

function normalizeWhatsAppPhone(rawPhone: string, defaultCountryCode: string): string {
  const digits = digitsOnly(rawPhone);
  if (!digits) return '';
  if (digits.length === 10 && defaultCountryCode.trim()) {
    return `${digitsOnly(defaultCountryCode)}${digits}`;
  }
  return digits;
}

export function WhatsAppModal({
  isOpen,
  job,
  khataCustomer = null,
  shopProfile,
  initialReceiptLayout = 'a4',
  onClose,
}: WhatsAppModalProps) {
  const [countryCode, setCountryCode] = useState('91');
  const [phoneInput, setPhoneInput] = useState('');
  const [message, setMessage] = useState('');
  const [copied, setCopied] = useState(false);
  const [receiptLayout, setReceiptLayout] = useState<ReceiptLayoutMode>(initialReceiptLayout);
  const [isProcessingPdf, setIsProcessingPdf] = useState(false);
  const [pdfFeedback, setPdfFeedback] = useState<{
    type: 'success' | 'info' | 'error';
    text: string;
  } | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setPdfFeedback(null);
    setReceiptLayout(initialReceiptLayout);
    if (khataCustomer) {
      setPhoneInput(khataCustomer.customerPhone || '');
      setMessage(buildKhataWhatsAppReminderMessage(khataCustomer, shopProfile));
      setCopied(false);
    } else if (job) {
      setPhoneInput(job.customerPhone || '');
      setMessage(buildDefaultMessage(job, shopProfile, 'auto'));
      setCopied(false);
    }
  }, [isOpen, job, khataCustomer, shopProfile, initialReceiptLayout]);

  if (!isOpen || (!job && !khataCustomer)) return null;

  const isJobMode = Boolean(job && !khataCustomer);
  const supportsDirectPdfShare = canSharePdfFiles();
  const pdfFileName = job ? buildReceiptFileName(job, receiptLayout) : '';

  const fullDigits = normalizeWhatsAppPhone(phoneInput, countryCode);
  const whatsappUrl = fullDigits
    ? `https://api.whatsapp.com/send?phone=${encodeURIComponent(fullDigits)}&text=${encodeURIComponent(message)}`
    : `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard unavailable
    }
  };

  const handleDownloadPdfOnly = async () => {
    if (!job || isProcessingPdf) return;
    setIsProcessingPdf(true);
    setPdfFeedback(null);
    try {
      const { blob, fileName } = await generateReceiptPdf(job, shopProfile, receiptLayout);
      triggerPdfDownload(blob, fileName);
      setPdfFeedback({
        type: 'success',
        text: `Downloaded ${fileName}. Ready to attach in WhatsApp.`,
      });
    } catch {
      setPdfFeedback({
        type: 'error',
        text: 'Could not generate the receipt PDF. Please try again.',
      });
    } finally {
      setIsProcessingPdf(false);
    }
  };

  const handleSharePdfOnWhatsApp = async () => {
    if (!job || isProcessingPdf) return;
    setIsProcessingPdf(true);
    setPdfFeedback(null);
    try {
      const result = await shareReceiptPdfViaWhatsApp({
        job,
        shopProfile,
        layoutMode: receiptLayout,
        whatsappUrl,
        messageText: message,
      });

      if (result.method === 'native-share') {
        setPdfFeedback({
          type: 'success',
          text: `Shared ${result.fileName} via device share sheet.`,
        });
      } else if (result.method === 'download-and-open') {
        setPdfFeedback({
          type: 'info',
          text: `${result.fileName} downloaded & WhatsApp chat opened. Drag or attach the downloaded PDF in WhatsApp to send.`,
        });
      }
    } catch {
      setPdfFeedback({
        type: 'error',
        text: 'Could not prepare the receipt PDF for WhatsApp. Please try again.',
      });
    } finally {
      setIsProcessingPdf(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm dark:bg-slate-950/80"
      role="dialog"
      aria-modal="true"
      aria-labelledby="whatsapp-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="flex max-h-[92vh] w-full max-w-xl flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-700/80 dark:bg-[#1E293B]">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400">
              <MessageCircle className="h-4 w-4" />
            </div>
            <div>
              <h3 id="whatsapp-modal-title" className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                {khataCustomer ? 'Khata Payment Reminder' : 'Share Receipt PDF on WhatsApp'}
              </h3>
              <p className="font-mono-tabular text-xs text-slate-500 dark:text-slate-400">
                {khataCustomer
                  ? `${khataCustomer.customerName} · ${khataCustomer.unpaidJobsCount} unpaid`
                  : `${job?.jobNumber ?? ''} · ${job?.customerName ?? ''}`}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-100"
            aria-label="Close WhatsApp modal"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto p-6">
          {/* Recipient Phone + Country Code */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">
                Country Code
              </label>
              <input
                type="text"
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value)}
                placeholder="91"
                className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 font-mono-tabular text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-[#0F172A] dark:text-slate-100 dark:placeholder:text-slate-500"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">
                Customer WhatsApp Number
              </label>
              <input
                type="tel"
                value={phoneInput}
                onChange={(e) => setPhoneInput(e.target.value)}
                placeholder="10-digit WhatsApp number"
                className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2 font-mono-tabular text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-[#0F172A] dark:text-slate-100 dark:placeholder:text-slate-500"
              />
            </div>
          </div>

          {/* Receipt PDF Attachment Card (Job Mode Only) */}
          {isJobMode && (
            <div className="rounded-xl border border-blue-200/80 bg-blue-50/70 p-3.5 dark:border-blue-500/30 dark:bg-blue-500/10">
              <div className="flex flex-wrap items-center justify-between gap-2.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-blue-600/15 text-blue-700 dark:bg-blue-500/20 dark:text-blue-300">
                    <FileText className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                      Print Receipt PDF Attachment
                    </p>
                    <p className="truncate font-mono-tabular text-[11px] text-slate-600 dark:text-slate-300">
                      {pdfFileName}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div
                    className="inline-flex items-center rounded-lg border border-slate-200 bg-white p-0.5 dark:border-slate-700 dark:bg-[#0F172A]"
                    role="group"
                    aria-label="Receipt PDF format"
                  >
                    <button
                      type="button"
                      onClick={() => setReceiptLayout('a4')}
                      className={`inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-[11px] font-medium transition-colors ${
                        receiptLayout === 'a4'
                          ? 'bg-[#2563EB] text-white'
                          : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100'
                      }`}
                    >
                      <FileText className="h-3 w-3" />
                      <span>A4</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setReceiptLayout('thermal')}
                      className={`inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-[11px] font-medium transition-colors ${
                        receiptLayout === 'thermal'
                          ? 'bg-[#2563EB] text-white'
                          : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100'
                      }`}
                    >
                      <Receipt className="h-3 w-3" />
                      <span>80mm</span>
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={handleDownloadPdfOnly}
                    disabled={isProcessingPdf}
                    className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-[11px] font-medium text-slate-700 transition-colors hover:bg-slate-100 disabled:opacity-60 dark:border-slate-700 dark:bg-[#0F172A] dark:text-slate-200 dark:hover:bg-slate-800"
                    title="Download receipt PDF"
                  >
                    {isProcessingPdf ? (
                      <Loader2 className="h-3 w-3 animate-spin" />
                    ) : (
                      <Download className="h-3 w-3" />
                    )}
                    <span>PDF</span>
                  </button>
                </div>
              </div>

              <p className="mt-2 text-[11px] leading-relaxed text-slate-600 dark:text-slate-300">
                {supportsDirectPdfShare
                  ? 'Generates the exact Print Receipt PDF and attaches it directly via your device share sheet.'
                  : 'Generates and downloads the exact Print Receipt PDF, then opens the customer chat in WhatsApp so you can attach/drop the file immediately.'}
              </p>

              {pdfFeedback && (
                <div
                  className={`mt-2.5 rounded-lg border px-3 py-2 text-[11px] font-medium leading-relaxed ${
                    pdfFeedback.type === 'success'
                      ? 'border-emerald-300 bg-emerald-50 text-emerald-800 dark:border-emerald-500/40 dark:bg-emerald-500/15 dark:text-emerald-200'
                      : pdfFeedback.type === 'error'
                        ? 'border-red-300 bg-red-50 text-red-800 dark:border-red-500/40 dark:bg-red-500/15 dark:text-red-200'
                        : 'border-blue-300 bg-white text-blue-800 dark:border-blue-500/40 dark:bg-[#0F172A] dark:text-blue-200'
                  }`}
                >
                  {pdfFeedback.text}
                </div>
              )}
            </div>
          )}

          {/* Quick Template Switcher */}
          {isJobMode && job && (
            <div>
              <span className="mb-1.5 block text-xs font-medium text-slate-600 dark:text-slate-400">
                Quick Templates
              </span>
              <div className="flex flex-wrap gap-2">
                {[
                  { key: 'status' as const, label: 'Status Update' },
                  { key: 'ready' as const, label: 'Ready for Pickup' },
                  { key: 'delivered' as const, label: 'Delivered & Warranty' },
                ].map((tpl) => (
                  <button
                    key={tpl.key}
                    type="button"
                    onClick={() => setMessage(buildDefaultMessage(job, shopProfile, tpl.key))}
                    className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:border-emerald-500/50 hover:text-emerald-700 dark:border-slate-700 dark:bg-[#0F172A] dark:text-slate-300 dark:hover:border-emerald-500/40 dark:hover:text-emerald-200"
                  >
                    {tpl.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Editable Message */}
          <div>
            <div className="mb-1.5 flex items-center justify-between text-xs">
              <label htmlFor="wa-message-body" className="font-medium text-slate-600 dark:text-slate-400">
                Message Preview (Editable)
              </label>
              <span className="font-mono-tabular text-[11px] text-slate-500 dark:text-slate-400">
                Target: {fullDigits ? `+${fullDigits}` : 'Select recipient in WhatsApp'}
              </span>
            </div>
            <textarea
              id="wa-message-body"
              rows={8}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 py-2.5 text-xs leading-relaxed text-slate-900 focus:border-emerald-500 focus:outline-none dark:border-slate-700 dark:bg-[#0F172A] dark:text-slate-100"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2.5 border-t border-slate-200 bg-slate-50 px-6 py-4 dark:border-slate-800 dark:bg-[#0F172A]">
          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 hover:text-slate-900 dark:border-slate-700 dark:bg-[#1E293B] dark:text-slate-200 dark:hover:text-white"
          >
            {copied ? (
              <>
                <Check className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5" />
                <span>Copy Text</span>
              </>
            )}
          </button>

          <div className="flex flex-wrap items-center gap-2">
            {isJobMode ? (
              <>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100 hover:text-slate-900 dark:border-slate-700 dark:bg-[#1E293B] dark:text-slate-200 dark:hover:text-white"
                >
                  <span>Text Only</span>
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>

                <button
                  type="button"
                  onClick={handleSharePdfOnWhatsApp}
                  disabled={isProcessingPdf}
                  className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-emerald-500 disabled:opacity-60"
                >
                  {isProcessingPdf ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : supportsDirectPdfShare ? (
                    <Share2 className="h-3.5 w-3.5" />
                  ) : (
                    <FileText className="h-3.5 w-3.5" />
                  )}
                  <span>
                    {isProcessingPdf
                      ? 'Generating PDF...'
                      : supportsDirectPdfShare
                        ? 'Share Receipt PDF'
                        : 'Download PDF & Open WhatsApp'}
                  </span>
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={onClose}
                  className="rounded-xl border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 hover:text-slate-900 dark:border-slate-700 dark:bg-[#1E293B] dark:text-slate-300 dark:hover:text-white"
                >
                  Close
                </button>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-emerald-500"
                >
                  <span>Send via WhatsApp Web</span>
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
